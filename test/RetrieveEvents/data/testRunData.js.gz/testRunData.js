window.testRunData = {
  "testRunName": "b9b9932f-f252-44fe-9cec-b1c0202c0360",
  "displayName": "TestRun_5/3/2024_3:13:34 PM",
  "testRunDescription": "rerunning",
  "testName": "2c459a63-4327-4da15-ac05-31a61ce7b9bb",
  "testRunId": "b10ca49e-f485-4256-b3bd-8ed98c4119ec",
  "lastUpdatedBy": "aztestkrchanda@outlook.com",
  "createdOn": "2024-05-03T09:43:39.415Z",
  "lastUpdatedOn": "2024-05-03T09:59:09.213Z",
  "startTime": "2024-05-03T09:46:10Z",
  "endTime": "2024-05-03T09:51:19Z",
  "engineInstances": 2,
  "testResult": "NOT_APPLICABLE",
  "status": "FAILED",
  "errorDetails": [
    {
      "message" : "Test run failed due to high error rate",
    }
  ],
  "createdBy": "aztestkrchanda@outlook.com",
  "duration": 309000,
  "passFailCriteria": {
    "passFailMetrics": {
      "1aaac481-97fe-4974-892c-c7dc1a1319f5": {
        "clientmetric": "response_time_ms",
        "aggregate": "p50",
        "condition": ">",
        "value": 10,
        "action": "continue",
        "actualValue": 186,
        "result": "failed"
      }
    },
    "passFailServerMetrics": {
      "73e58334-5313-4e58-98c8-716d77831c30": {
        "resourceId": "/subscriptions/7c71b563-0dc0-4bc0-bcf6-06f8f0516c7a/resourceGroups/cnt-integration-tests-rg/providers/Microsoft.Web/serverfarms/cnt-integration-tests-server",
        "metricNamespace": "microsoft.web/serverfarms",
        "metricName": "CpuPercentage",
        "aggregation": "Average",
        "condition": ">",
        "value": 50.0,
        "action": "continue",
        "actualValue": 5.75,
        "result": "passed"
      }
    }
  },
  "testRunStatistics": {
    "Get": {
      "transaction": "Get",
      "sampleCount": 13242.0,
      "errorCount": 0.0,
      "errorPct": 0.0,
      "meanResTime": 61.0,
      "medianResTime": 36.0,
      "minResTime": 6.0,
      "maxResTime": 15550.0,
      "pct75ResTime": 47.0,
      "pct1ResTime": 50.0,
      "pct2ResTime": 54.0,
      "pct96ResTime": 56.0,
      "pct97esTime": null,
      "pct98ResTime": 84.0,
      "pct3ResTime": 391.0,
      "pct999ResTime": 15310.0,
      "pct9999ResTime": 15500.0,
      "throughput": 85.69902912621359,
      "receivedKBytesPerSec": null,
      "sentKBytesPerSec": null
    },
    "Total": {
      "transaction": "Total",
      "sampleCount": 26481.0,
      "errorCount": 39.0,
      "errorPct": 0.0,
      "meanResTime": 1137.0,
      "medianResTime": 93.0,
      "minResTime": 6.0,
      "maxResTime": 31790.0,
      "pct75ResTime": 670.0,
      "pct1ResTime": 2441.0,
      "pct2ResTime": 6700.0,
      "pct96ResTime": 8046.0,
      "pct97esTime": null,
      "pct98ResTime": 12888.0,
      "pct3ResTime": 17464.0,
      "pct999ResTime": 30090.0,
      "pct9999ResTime": 31130.0,
      "throughput": 85.69902912621359,
      "receivedKBytesPerSec": null,
      "sentKBytesPerSec": null
    },
    "Add to cart - PUT": {
      "transaction": "Add to cart - PUT",
      "sampleCount": 13239.0,
      "errorCount": 39.0,
      "errorPct": 0.0,
      "meanResTime": 2212.0,
      "medianResTime": 665.0,
      "minResTime": 89.0,
      "maxResTime": 31790.0,
      "pct75ResTime": 1457.0,
      "pct1ResTime": 6532.0,
      "pct2ResTime": 10960.0,
      "pct96ResTime": 12422.0,
      "pct97esTime": null,
      "pct98ResTime": 17418.0,
      "pct3ResTime": 21961.0,
      "pct999ResTime": 30640.0,
      "pct9999ResTime": 31180.0,
      "throughput": 85.69902912621359,
      "receivedKBytesPerSec": null,
      "sentKBytesPerSec": null
    }
  },
  "samplerNames": [
    "Add to cart - PUT",
    "Get"
  ],
  "responseCodes": [
    "500"
  ],
  "groupBy": [
    "5s"
  ],
  "percentiles": [
    "Average",
    "Percentile75",
    "Percentile90",
    "Percentile95",
    "Percentile96",
    "Percentile97",
    "Percentile98",
    "Percentile99",
    "Percentile999",
    "Percentile9999"
  ],
  "regions": [
    "Central US",
    "Australia East"
  ],
  "regionalLoadTestConfig": {
    "Central US": {
      "engineInstances": 1
    },
    "Australia East": {
      "engineInstances": 1
    }
  },
  "regionalStatistics": {
    "Central US": {
      "transaction": "Central US",
      "sampleCount": 15162.0,
      "errorCount": 20.0,
      "errorPct": 0.0,
      "meanResTime": 996.0,
      "medianResTime": 92.0,
      "minResTime": 21.0,
      "maxResTime": 31130.0,
      "pct75ResTime": 270.0,
      "pct1ResTime": 2367.0,
      "pct2ResTime": 6391.0,
      "pct96ResTime": 7438.0,
      "pct97esTime": null,
      "pct98ResTime": 12168.0,
      "pct3ResTime": 16863.0,
      "pct999ResTime": 30070.0,
      "pct9999ResTime": 30110.0,
      "throughput": 85.69902912621359,
      "receivedKBytesPerSec": null,
      "sentKBytesPerSec": null
    },
    "Australia East": {
      "transaction": "Australia East",
      "sampleCount": 11319.0,
      "errorCount": 19.0,
      "errorPct": 0.0,
      "meanResTime": 1326.0,
      "medianResTime": 615.0,
      "minResTime": 6.0,
      "maxResTime": 31790.0,
      "pct75ResTime": 815.0,
      "pct1ResTime": 2989.0,
      "pct2ResTime": 7009.0,
      "pct96ResTime": 8867.0,
      "pct97esTime": null,
      "pct98ResTime": 13687.0,
      "pct3ResTime": 17990.0,
      "pct999ResTime": 30640.0,
      "pct9999ResTime": 31180.0,
      "throughput": 85.69902912621359,
      "receivedKBytesPerSec": null,
      "sentKBytesPerSec": null
    },
    "Total": {
      "transaction": "Total",
      "sampleCount": 26481.0,
      "errorCount": 39.0,
      "errorPct": 0.0,
      "meanResTime": 1137.0,
      "medianResTime": 93.0,
      "minResTime": 6.0,
      "maxResTime": 31790.0,
      "pct75ResTime": 670.0,
      "pct1ResTime": 2441.0,
      "pct2ResTime": 6700.0,
      "pct96ResTime": 8046.0,
      "pct97esTime": null,
      "pct98ResTime": 12888.0,
      "pct3ResTime": 17464.0,
      "pct999ResTime": 30090.0,
      "pct9999ResTime": 31130.0,
      "throughput": 85.69902912621359,
      "receivedKBytesPerSec": null,
      "sentKBytesPerSec": null
    }
  }
}